"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";

import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import IconButton from "@mui/material/IconButton";
import CircularProgress from "@mui/material/CircularProgress";
import MenuItem from "@mui/material/MenuItem";

import SearchIcon from "@mui/icons-material/Search";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";

type SecurityLog = {
  id: string;
  userName: string | null;
  section: string;
  action: string;
  createdAt: string;
};

function formatDate(date: string) {
  return new Date(date).toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });
}

function formatTime(date: string) {
  return new Date(date).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
  });
}

export default function SecurityPage() {
  const [search, setSearch] = useState("");
  const [sectionFilter, setSectionFilter] = useState("ALL");
  const [page, setPage] = useState(1);

  const { data, isLoading: loading } = useQuery({
    queryKey: ["securityLogs", search, sectionFilter, page],
    queryFn: async () => {
      const res = await fetch(
        `/api/admin/security?search=${encodeURIComponent(
          search
        )}&section=${encodeURIComponent(sectionFilter)}&page=${page}`,
        { cache: "no-store" }
      );

      const result = await res.json();

      if (!res.ok) {
        throw new Error(result.error || "Failed to load security logs");
      }

      return result;
    },
    refetchInterval: 5000,
    refetchOnWindowFocus: true,
  });

  const logs: SecurityLog[] = data?.logs || [];
  const total = data?.total || 0;
  const totalPages = data?.totalPages || 1;

  const start = total === 0 ? 0 : (page - 1) * 5 + 1;
  const end = Math.min(page * 5, total);

  return (
    <Box
      sx={{
        minHeight: "100vh",
        bgcolor: "#fff",
        px: "62px",
        py: "46px",
        pb: "130px",
      }}
    >
      <Typography
        sx={{
          fontSize: "32px",
          fontWeight: 800,
          color: "#111",
          mb: "14px",
        }}
      >
        Security Logs
      </Typography>

      <Box sx={{ display: "flex", gap: 1.5, mb: 3.5, flexWrap: "wrap" }}>
        <TextField
          size="small"
          placeholder="Search user, section, or action..."
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1);
          }}
          sx={{
            width: 360,
            "& .MuiOutlinedInput-root": {
              height: 38,
              borderRadius: "8px",
              bgcolor: "#fff",
            },
          }}
          slotProps={{
            input: {
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: "#999" }} />
                </InputAdornment>
              ),
            },
          }}
        />

        <TextField
          select
          size="small"
          value={sectionFilter}
          onChange={(e) => {
            setSectionFilter(e.target.value);
            setPage(1);
          }}
          sx={{
            width: 210,
            "& .MuiOutlinedInput-root": {
              height: 38,
              borderRadius: "8px",
              bgcolor: "#fff",
            },
          }}
        >
          <MenuItem value="ALL">All Sections</MenuItem>
          <MenuItem value="Authentication">Authentication</MenuItem>
          <MenuItem value="Appointments">Appointments</MenuItem>
          <MenuItem value="Customers">Customers</MenuItem>
          <MenuItem value="Staff">Staff</MenuItem>
          <MenuItem value="Sales">Sales</MenuItem>
          <MenuItem value="Loyalty Card">Loyalty Card</MenuItem>
          <MenuItem value="System">System</MenuItem>
        </TextField>
      </Box>

      <Box>
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "160px 130px 180px 190px 1fr",
            py: 1.5,
            borderBottom: "1px solid #e5e5e5",
          }}
        >
          {["Date", "Time", "User", "Section", "Action"].map((item) => (
            <Typography
              key={item}
              sx={{
                fontSize: 14,
                fontWeight: 800,
                color: "#555",
              }}
            >
              {item}
            </Typography>
          ))}
        </Box>

        {loading ? (
          <Box sx={{ py: 8, textAlign: "center" }}>
            <CircularProgress size={28} />
          </Box>
        ) : logs.length === 0 ? (
          <Typography sx={{ py: 4, color: "#777" }}>
            No security logs found.
          </Typography>
        ) : (
          logs.map((log) => (
            <Box
              key={log.id}
              sx={{
                display: "grid",
                gridTemplateColumns: "160px 130px 180px 190px 1fr",
                py: 2,
                borderBottom: "1px solid #e5e5e5",
              }}
            >
              <Typography sx={{ fontSize: 14, color: "#777", fontWeight: 600 }}>
                {formatDate(log.createdAt)}
              </Typography>

              <Typography sx={{ fontSize: 14, color: "#777", fontWeight: 600 }}>
                {formatTime(log.createdAt)}
              </Typography>

              <Typography sx={{ fontSize: 14, color: "#222", fontWeight: 700 }}>
                {log.userName || "Unknown"}
              </Typography>

              <Typography sx={{ fontSize: 14, color: "#222", fontWeight: 700 }}>
                {log.section}
              </Typography>

              <Typography sx={{ fontSize: 14, color: "#222", fontWeight: 600 }}>
                {log.action}
              </Typography>
            </Box>
          ))
        )}
      </Box>

      <Box
        sx={{
          position: "fixed",
          left: 270,
          right: 70,
          bottom: 58,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          bgcolor: "#fff",
          py: 1,
        }}
      >
        <Typography sx={{ fontSize: 18, color: "#111", fontWeight: 500 }}>
          Showing {start} to {end} of {total} Entries
        </Typography>

        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <IconButton
            disabled={page <= 1}
            onClick={() => setPage((prev) => Math.max(prev - 1, 1))}
            sx={{
              bgcolor: "#e0e0e0",
              width: 32,
              height: 32,
              "&:hover": { bgcolor: "#d5d5d5" },
            }}
          >
            <ChevronLeftIcon />
          </IconButton>

          <Box
            sx={{
              width: 30,
              height: 32,
              borderRadius: "8px",
              bgcolor: "#f7b500",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: 800,
              color: "#111",
            }}
          >
            {page}
          </Box>

          <IconButton
            disabled={page >= totalPages}
            onClick={() => setPage((prev) => Math.min(prev + 1, totalPages))}
            sx={{
              bgcolor: "#e0e0e0",
              width: 32,
              height: 32,
              "&:hover": { bgcolor: "#d5d5d5" },
            }}
          >
            <ChevronRightIcon />
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
}