'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Avatar from '@mui/material/Avatar';
import IconButton from '@mui/material/IconButton';
import Drawer from '@mui/material/Drawer';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useTheme } from '@mui/material/styles';

import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import DashboardIcon from '@mui/icons-material/Dashboard';
import PersonIcon from '@mui/icons-material/Person';
import BuildIcon from '@mui/icons-material/Build';
import GroupIcon from '@mui/icons-material/Group';
import EventIcon from '@mui/icons-material/Event';
import MonetizationOnIcon from '@mui/icons-material/MonetizationOn';
import StarIcon from '@mui/icons-material/Star';
import CardGiftcardIcon from '@mui/icons-material/CardGiftcard';
import DescriptionIcon from '@mui/icons-material/Description';
import AdminPanelSettingsIcon from '@mui/icons-material/AdminPanelSettings';
import SmartToyIcon from '@mui/icons-material/SmartToy';
import SecurityIcon from '@mui/icons-material/Security';

const menuItems = [
  { label: 'Dashboard', icon: DashboardIcon, path: '/admin/dashboard', roles: ['OWNER', 'RECEPTIONIST'] },
  { label: 'Customers', icon: GroupIcon, path: '/admin/customers', roles: ['OWNER', 'RECEPTIONIST'] },
  { label: 'Services', icon: BuildIcon, path: '/admin/services', roles: ['OWNER'] },
  { label: 'Barbers', icon: PersonIcon, path: '/admin/barbers', roles: ['OWNER', 'RECEPTIONIST', 'BARBER'] },
  { label: 'Appointments', icon: EventIcon, path: '/admin/appointments', roles: ['OWNER', 'RECEPTIONIST'] },
  { label: 'Sales', icon: MonetizationOnIcon, path: '/admin/sales', roles: ['OWNER', 'RECEPTIONIST'] },
  { label: 'Customer Reviews', icon: StarIcon, path: '/admin/reviews', roles: ['OWNER'] },
  { label: 'Loyalty Card', icon: CardGiftcardIcon, path: '/admin/loyaltyCard', roles: ['OWNER', 'RECEPTIONIST'] },
  { label: 'Reports', icon: DescriptionIcon, path: '/admin/reports', roles: ['OWNER'] },
  { label: 'User Management', icon: AdminPanelSettingsIcon, path: '/admin/user-management', roles: ['OWNER'] },
  { label: 'Chatbot', icon: SmartToyIcon, path: '/admin/chatbot', roles: ['OWNER'] },
  { label: 'Security Logs', icon: SecurityIcon, path: '/admin/security', roles: ['OWNER'] },
];

type SidebarProps = {
  currentName: string;
  currentRole: string;
};

// ─── Shared nav list ──────────────────────────────────────────────────────────

function NavList({
  filteredMenu,
  pathname,
  currentName,
  currentRole,
  onClose,
  onSignOut,
}: {
  filteredMenu: typeof menuItems;
  pathname: string | null;
  currentName: string;
  currentRole: string;
  onClose?: () => void;
  onSignOut: () => void;
}) {
  const currentInitial = currentName?.charAt(0)?.toUpperCase() || 'U';

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Profile */}
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          gap: 1.5,
          p: 2,
          pb: 2,
          borderBottom: '1px solid #333',
        }}
      >
        <Avatar sx={{ width: 40, height: 40, bgcolor: '#666' }}>
          {currentInitial}
        </Avatar>
        <Box>
          <Typography sx={{ fontSize: 14, fontWeight: 700, color: '#fff' }}>
            {currentName}
          </Typography>
          <Typography sx={{ fontSize: 12, color: '#999' }}>{currentRole}</Typography>
        </Box>
      </Box>

      {/* Logout */}
      <Box sx={{ px: 2, pt: 2, pb: 1 }}>
        <Button
          variant="contained"
          size="small"
          onClick={onSignOut}
          sx={{
            width: '100%',
            bgcolor: '#333',
            color: '#fff',
            textTransform: 'none',
            '&:hover': { bgcolor: '#444' },
          }}
        >
          Logout
        </Button>
      </Box>

      {/* Menu */}
      <List sx={{ p: 1, flex: 1, overflowY: 'auto' }}>
        {filteredMenu.map((item) => {
          const Icon = item.icon;
          const isActive = pathname?.startsWith(item.path);

          return (
            <ListItem key={item.path} disablePadding sx={{ mb: 0.5 }}>
              <Link
                href={item.path}
                style={{ width: '100%', textDecoration: 'none' }}
                onClick={onClose}
              >
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    px: 2,
                    py: 1.5,
                    borderRadius: 1,
                    bgcolor: isActive ? '#ffc107' : 'transparent',
                    color: isActive ? '#000' : '#fff',
                    '&:hover': { bgcolor: isActive ? '#ffc107' : '#333' },
                    transition: 'background-color 0.15s',
                  }}
                >
                  <ListItemIcon sx={{ minWidth: 40, color: isActive ? '#000' : '#fff' }}>
                    <Icon fontSize="small" />
                  </ListItemIcon>
                  <ListItemText
                    primary={item.label}
                    sx={{
                      '& .MuiListItemText-primary': {
                        fontSize: 14,
                        fontWeight: isActive ? 700 : 500,
                      },
                    }}
                  />
                </Box>
              </Link>
            </ListItem>
          );
        })}
      </List>
    </Box>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────

export default function Sidebar({ currentName, currentRole }: SidebarProps) {
  const pathname = usePathname();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [drawerOpen, setDrawerOpen] = useState(false);
  const router = useRouter();
  const supabase = createClient();

  const currentInitial = currentName?.charAt(0)?.toUpperCase() || 'U';

  const filteredMenu = menuItems.filter((item) =>
    item.roles ? item.roles.includes(currentRole) : false
  );

  // sign-out
    const handleSignOut = async () => {
    await supabase.auth.signOut();
    router.push("/");
  };
  // ── Desktop: static sidebar ────────────────────────────────────────────────
  if (!isMobile) {
    return (
      <Box
        sx={{
          width: 240,
          flexShrink: 0,
          bgcolor: '#000',
          color: '#fff',
          minHeight: '100vh',
        }}
      >
        <NavList
          filteredMenu={filteredMenu}
          pathname={pathname}
          currentName={currentName}
          currentRole={currentRole}
          onSignOut={handleSignOut}
        />
      </Box>
    );
  }

  // ── Mobile: top AppBar + Drawer ────────────────────────────────────────────
  return (
    <>
      <AppBar
        position="fixed"
        elevation={0}
        sx={{
          bgcolor: '#000',
          borderBottom: '1px solid #222',
          zIndex: theme.zIndex.drawer + 1,
        }}
      >
        <Toolbar sx={{ justifyContent: 'space-between', minHeight: 56 }}>
          {/* Hamburger */}
          <IconButton
            edge="start"
            onClick={() => setDrawerOpen(true)}
            sx={{ color: '#fff' }}
            aria-label="Open menu"
          >
            <MenuIcon />
          </IconButton>

          {/* Logo / brand name — centered */}
          <Typography sx={{ fontSize: 16, fontWeight: 800, color: '#fff', letterSpacing: 1 }}>
            Admin
          </Typography>

          {/* Profile avatar */}
          <Avatar
            sx={{
              width: 34,
              height: 34,
              bgcolor: '#666',
              fontSize: 15,
              fontWeight: 700,
              cursor: 'pointer',
            }}
          >
            {currentInitial}
          </Avatar>
        </Toolbar>
      </AppBar>


      {/* Drawer */}
      <Drawer
        anchor="left"
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        slotProps={{ paper: { 
          sx: {
            width: 260,
            bgcolor: '#000',
            color: '#fff',
          },
        }
        }}
      >
        {/* Close button row */}
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'flex-end',
            px: 1,
            pt: 1,
          }}
        >
          <IconButton onClick={() => setDrawerOpen(false)} sx={{ color: '#fff' }}>
            <CloseIcon />
          </IconButton>
        </Box>

        <NavList
          filteredMenu={filteredMenu}
          pathname={pathname}
          currentName={currentName}
          currentRole={currentRole}
          onClose={() => setDrawerOpen(false)}
          onSignOut={handleSignOut}
        />
      </Drawer>
    </>
  );
}